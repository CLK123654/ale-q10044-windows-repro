# 内容申诉线程的SQLite审计

database/content_appeals.db保存工单、事件、规则目录和SLA政策，数据为虚构的运营样例。rules/report_contract.json给出截止时间、事件动作和报告清单。rules/queue_assignments.csv给出队列与责任团队的对应关系。starter/rebuild_appeal_audit.sql是待补的开工文件。

完成SQL后，将文件保存为output/sql/rebuild_appeal_audit.sql，再在当前input_data目录执行：

    npm run audit

入口会读取两份规则文件，复制输入数据库，并在同一个SQLite会话中导入运行规则后执行SQL。成功时，output中会出现派生数据库、四份CSV和audit_summary.json；执行中断时，入口会清理未完成的数据库和报告。
