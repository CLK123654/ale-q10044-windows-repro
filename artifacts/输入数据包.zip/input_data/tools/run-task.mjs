import fs from "node:fs";
import path from "node:path";
import process from "node:process";
import { fileURLToPath } from "node:url";
import { spawnSync } from "node:child_process";

const toolsDir = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(toolsDir, "..");
const sourceDatabase = path.join(root, "database", "content_appeals.db");
const contractFile = path.join(root, "rules", "report_contract.json");
const queueFile = path.join(root, "rules", "queue_assignments.csv");
const outputDir = path.join(root, "output");
const outputDatabase = path.join(outputDir, "appeal_thread_audit.db");
const reportsDir = path.join(outputDir, "reports");
const sqlFile = path.join(outputDir, "sql", "rebuild_appeal_audit.sql");
const runtimeSql = path.join(outputDir, ".runtime_inputs.sql");
const sqliteExecutable = process.env.SQLITE3_PATH
  ?? (process.platform === "win32" ? "sqlite3.exe" : "sqlite3");

function removePriorOutput() {
  fs.rmSync(outputDatabase, { force: true });
  fs.rmSync(reportsDir, { recursive: true, force: true });
  fs.rmSync(runtimeSql, { force: true });
}

function fail(message, code = 1) {
  console.error(message);
  process.exit(code);
}

function sqlLiteral(value) {
  return `'${String(value).replaceAll("'", "''")}'`;
}

function parseCsv(text) {
  const lines = text.trim().split(/\r?\n/u);
  const headers = lines.shift()?.split(",") ?? [];
  return lines.filter(Boolean).map((line) => {
    const values = line.split(",");
    return Object.fromEntries(headers.map((header, index) => [header, values[index] ?? ""]));
  });
}

for (const file of [sourceDatabase, contractFile, queueFile, sqlFile]) {
  if (!fs.existsSync(file)) fail(`缺少运行文件：${file}`, 2);
}

let contract;
let queueAssignments;
try {
  contract = JSON.parse(fs.readFileSync(contractFile, "utf8"));
  const queueText = fs.readFileSync(queueFile, "utf8");
  if (queueText.split(/\r?\n/u, 1)[0] !== "queue,owner_team") {
    fail("queue_assignments.csv表头错误", 3);
  }
  if (/\r?\n\r?\n/u.test(queueText)) fail("queue_assignments.csv含空数据行", 3);
  queueAssignments = parseCsv(queueText);
} catch (error) {
  fail(`规则文件无法读取：${error.message}`, 3);
}

if (!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$/u.test(contract.report_cutoff_utc)) {
  fail("report_cutoff_utc格式错误", 3);
}
if (typeof contract.first_response_action !== "string" || !contract.first_response_action) {
  fail("first_response_action缺失", 3);
}
if (!Array.isArray(contract.terminal_actions) || contract.terminal_actions.length === 0) {
  fail("terminal_actions缺失", 3);
}
if (!Array.isArray(contract.quality_issue_codes) || contract.quality_issue_codes.length !== 2) {
  fail("quality_issue_codes不完整", 3);
}
if (!Array.isArray(contract.required_reports) || contract.required_reports.length !== 5) {
  fail("required_reports不完整", 3);
}
if (queueAssignments.length === 0 || queueAssignments.some((row) => !row.queue || !row.owner_team)) {
  fail("queue_assignments.csv内容不完整", 3);
}

const uniqueQueues = new Set(queueAssignments.map((row) => row.queue));
if (uniqueQueues.size !== queueAssignments.length) fail("queue字段重复", 3);
for (const report of contract.required_reports) {
  if (path.basename(report) !== report || !/\.(csv|json)$/u.test(report)) {
    fail(`报告名称不可用：${report}`, 3);
  }
}

removePriorOutput();
fs.mkdirSync(reportsDir, { recursive: true });
fs.copyFileSync(sourceDatabase, outputDatabase);

const runtimeStatements = [
  "CREATE TEMP TABLE runtime_contract(report_cutoff_utc TEXT NOT NULL, first_response_action TEXT NOT NULL);",
  `INSERT INTO runtime_contract VALUES(${sqlLiteral(contract.report_cutoff_utc)},${sqlLiteral(contract.first_response_action)});`,
  "CREATE TEMP TABLE runtime_terminal_action(action TEXT PRIMARY KEY);",
  ...contract.terminal_actions.map((action) => `INSERT INTO runtime_terminal_action VALUES(${sqlLiteral(action)});`),
  "CREATE TEMP TABLE runtime_quality_issue_code(issue_code TEXT PRIMARY KEY);",
  ...contract.quality_issue_codes.map((code) => `INSERT INTO runtime_quality_issue_code VALUES(${sqlLiteral(code)});`),
  "CREATE TEMP TABLE runtime_queue_assignment(queue TEXT PRIMARY KEY NOT NULL CHECK(length(trim(queue)) > 0), owner_team TEXT NOT NULL CHECK(length(trim(owner_team)) > 0)) WITHOUT ROWID;",
  ".mode csv",
  `.import --skip 1 "${path.relative(root, queueFile).split(path.sep).join('/')}" runtime_queue_assignment`,
  "CREATE TEMP TABLE runtime_required_report(report_name TEXT PRIMARY KEY);",
  ...contract.required_reports.map((report) => `INSERT INTO runtime_required_report VALUES(${sqlLiteral(report)});`),
].join("\n");
fs.writeFileSync(runtimeSql, `${runtimeStatements}\n`, "utf8");

const runtimeRelative = path.relative(root, runtimeSql).split(path.sep).join("/");
const sqlRelative = path.relative(root, sqlFile).split(path.sep).join("/");
const execution = spawnSync(
  sqliteExecutable,
  [outputDatabase],
  {
    cwd: root,
    input: `.bail on\n.read "${runtimeRelative}"\n.read "${sqlRelative}"\n`,
    encoding: "utf8",
    timeout: 30_000,
    windowsHide: true,
  },
);
fs.rmSync(runtimeSql, { force: true });

if (execution.error) fail(`无法执行SQLite CLI：${execution.error.message}`, 4);
if (execution.status !== 0) {
  if (execution.stdout) process.stdout.write(execution.stdout);
  if (execution.stderr) process.stderr.write(execution.stderr);
  fail(`SQLite执行失败，退出码${execution.status}`, execution.status || 5);
}

for (const file of [outputDatabase, ...contract.required_reports.map((name) => path.join(reportsDir, name))]) {
  if (!fs.existsSync(file)) fail(`SQLite运行后缺少交付文件：${file}`, 6);
}

console.log("SQLite appeal audit completed");
