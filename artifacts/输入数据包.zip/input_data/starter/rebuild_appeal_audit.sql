-- Starter placeholder.
-- Replace it with SQLite SQL that builds thread_summary, sla_report,
-- rule_rollup, quality_exceptions and audit_summary in the copied output database.
PRAGMA foreign_keys=OFF;
